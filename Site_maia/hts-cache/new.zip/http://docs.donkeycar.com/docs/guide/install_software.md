<!DOCTYPE html>
<html class="writer-html5" lang="en" >
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link rel="shortcut icon" href="/img/favicon.ico" />
    <title>Donkey Car</title>
    <link rel="stylesheet" href="/css/theme.css" />
    <link rel="stylesheet" href="/css/theme_extra.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/10.5.0/styles/github.min.css" />
        <link href="/extra.css" rel="stylesheet" />
    
    <script src="/js/jquery-3.6.0.min.js" defer></script>
    <!--[if lt IE 9]>
      <script src="/js/html5shiv.min.js"></script>
    <![endif]-->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/10.5.0/highlight.min.js"></script>
      <script>hljs.initHighlightingOnLoad();</script> 
</head>

<body class="wy-body-for-nav" role="document">

  <div class="wy-grid-for-nav">
    <nav data-toggle="wy-nav-shift" class="wy-nav-side stickynav">
    <div class="wy-side-scroll">
      <div class="wy-side-nav-search">
          <a href="/." class="icon icon-home"> Donkey Car
        </a>
      </div>

      <div class="wy-menu wy-menu-vertical" data-spy="affix" role="navigation" aria-label="Navigation menu">
              <ul>
                <li class="toctree-l1"><a class="reference internal" href="/.">Home</a>
                </li>
              </ul>
              <p class="caption"><span class="caption-text">User Guide</span></p>
              <ul>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/build_hardware/">Build a car.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/install_software/">Install the software.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/create_application/">Create Donkeycar App.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/calibrate/">Calibrate steering and throttle.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/get_driving/">Get driving.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/train_autopilot/">Train an autopilot.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/utility/ui/">Donkey UI.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/deep_learning/simulator/">Donkey Simulator.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/deep_learning/virtual_race_league/">Virtual Race League.</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/guide/deep_learning/mobile_app/">Mobile app</a>
                  </li>
              </ul>
              <p class="caption"><span class="caption-text">Parts</span></p>
              <ul>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/about/">About</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/actuators/">Actuators</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/controllers/">Controllers</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/odometry/">Odometry/encoders</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/rc/">RC</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/rc_hat/">RC Hat</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/keras/">Keras</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/stores/">Stores</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/fastai/">Fastai</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/imu/">IMU</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/lidar/">Lidar</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/oled/">OLED</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/pins/">Pins</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/voice_control/">Voice Control</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/parts/stop_sign_detection/">Stop Sign Detection</a>
                  </li>
              </ul>
              <p class="caption"><span class="caption-text">Utilities</span></p>
              <ul>
                  <li class="toctree-l1"><a class="reference internal" href="/utility/donkey/">donkey</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/utility/ui/">UI</a>
                  </li>
              </ul>
              <p class="caption"><span class="caption-text">Developer Guide</span></p>
              <ul>
                  <li class="toctree-l1"><a class="reference internal" href="/dev_guide/contribute/">Contribute</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/dev_guide/tests/">Tests</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/dev_guide/model/">Create your own model</a>
                  </li>
              </ul>
              <p class="caption"><span class="caption-text">Cars</span></p>
              <ul>
                  <li class="toctree-l1"><a class="reference internal" href="/cars/supported_cars/">Supported Cars</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/cars/roll_your_own/">Roll Your Own</a>
                  </li>
              </ul>
              <p class="caption"><span class="caption-text">Support</span></p>
              <ul>
                  <li class="toctree-l1"><a class="reference internal" href="/support/faq/">FAQ</a>
                  </li>
                  <li class="toctree-l1"><a class="reference internal" href="/support/legacy/">Legacy</a>
                  </li>
              </ul>
      </div>
    </div>
    </nav>

    <section data-toggle="wy-nav-shift" class="wy-nav-content-wrap">
      <nav class="wy-nav-top" role="navigation" aria-label="Mobile navigation menu">
          <i data-toggle="wy-nav-top" class="fa fa-bars"></i>
          <a href="/.">Donkey Car</a>
        
      </nav>
      <div class="wy-nav-content">
        <div class="rst-content"><div role="navigation" aria-label="breadcrumbs navigation">
  <ul class="wy-breadcrumbs">
    <li><a href="/." class="icon icon-home" alt="Docs"></a> &raquo;</li>
    <li class="wy-breadcrumbs-aside">
    </li>
  </ul>
  <hr/>
</div>
          <div role="main" class="document" itemscope="itemscope" itemtype="http://schema.org/Article">
            <div class="section" itemprop="articleBody">
              

  <h1 id="404-page-not-found">404</h1>

  <p><strong>Page not found</strong></p>


            </div>
          </div><footer>

  <hr/>

  <div role="contentinfo">
    <!-- Copyright etc -->
  </div>

  Built with <a href="https://www.mkdocs.org/">MkDocs</a> using a <a href="https://github.com/readthedocs/sphinx_rtd_theme">theme</a> provided by <a href="https://readthedocs.org">Read the Docs</a>.
</footer>
          
        </div>
      </div>

    </section>

  </div>

  <div class="rst-versions" role="note" aria-label="Versions">
  <span class="rst-current-version" data-toggle="rst-current-version">
    
        <span>
          <a href="https://github.com/autorope/donkeydocs/" class="fa fa-github" style="color: #fcfcfc"> GitHub</a>
        </span>
    
    
    
  </span>
</div>
    <script>var base_url = '/';</script>
    <script src="/js/theme_extra.js" defer></script>
    <script src="/js/theme.js" defer></script>
    <script defer>
        window.onload = function () {
            SphinxRtdTheme.Navigation.enable(true);
        };
    </script>

</body>
</html>
